﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Lab4.Publisher.Models;

[Table("tbl_News_Sticker")]
public class NewsSticker : BaseModel
{
}