﻿using Lab4.Publisher.Models;

namespace Lab4.Publisher.Repositories.Interfaces;

public interface ICreatorRepository : IBaseRepository<Creator>
{
}