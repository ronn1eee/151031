﻿namespace Lab4.Discussion.Exceptions
{
    public static class ErrorMessages
    {
        public static string NoteNotFoundMessage(long id) => $"Note with id {id} was not found.";
    }
}
