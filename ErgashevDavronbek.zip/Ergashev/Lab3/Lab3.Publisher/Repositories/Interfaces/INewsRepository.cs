﻿using Lab3.Publisher.Models;

namespace Lab3.Publisher.Repositories.Interfaces;

public interface INewsRepository : IBaseRepository<News>
{
}