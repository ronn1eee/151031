﻿using FluentValidation;
using Lab3.Discussion.DTO.RequestDTO;

namespace Lab3.Discussion.Infrastructure.Validators
{
    public class NoteRequestDtoValidator : AbstractValidator<NoteRequestDto>
    {
        public NoteRequestDtoValidator()
        {
            RuleFor(dto => dto.Content).Length(2, 2048);
        }
    }
}
