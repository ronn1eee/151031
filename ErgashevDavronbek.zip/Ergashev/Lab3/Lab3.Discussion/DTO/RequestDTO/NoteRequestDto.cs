﻿namespace Lab3.Discussion.DTO.RequestDTO
{
    public class NoteRequestDto
    {
        public long Id { get; set; }
        public long NewsId { get; set; }
        public string Content { get; set; }
    }
}
