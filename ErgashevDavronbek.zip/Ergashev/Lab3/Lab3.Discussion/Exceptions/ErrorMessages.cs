﻿namespace Lab3.Discussion.Exceptions
{
    public static class ErrorMessages
    {
        public static string NoteNotFoundMessage(long id) => $"Note with id {id} was not found.";
    }
}
