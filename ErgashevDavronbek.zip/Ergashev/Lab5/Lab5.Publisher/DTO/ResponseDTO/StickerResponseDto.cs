﻿namespace Lab5.Publisher.DTO.ResponseDTO;

public class StickerResponseDto
{
    public long Id { get; set; }
    public string Name { get; set; }
}