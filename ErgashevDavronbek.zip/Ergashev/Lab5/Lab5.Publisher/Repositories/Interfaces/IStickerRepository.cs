﻿using Lab5.Publisher.Models;

namespace Lab5.Publisher.Repositories.Interfaces;

public interface IStickerRepository : IBaseRepository<Sticker>
{
}