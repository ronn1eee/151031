﻿using Lab2.Models;

namespace Lab2.Repositories.Interfaces
{
    public interface ICreatorRepository : IBaseRepository<Creator>
    {

    }
}
