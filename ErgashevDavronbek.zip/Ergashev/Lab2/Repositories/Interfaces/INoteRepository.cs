﻿using Lab2.Models;

namespace Lab2.Repositories.Interfaces
{
    public interface INoteRepository : IBaseRepository<Note>
    {

    }
}
