﻿using Lab2.Models;

namespace Lab2.Repositories.Interfaces
{
    public interface IStickerRepository : IBaseRepository<Sticker>
    {

    }
}
