﻿namespace Lab2.DTO.RequestDTO
{
    public class StickerRequestDto
    {
        public long Id { get; set; }
        public string Name { get; set; }
    }
}
