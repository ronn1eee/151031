﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Lab2.Models
{
    [Table("tbl_News_Sticker")]
    public class NewsSticker : BaseModel
    {
    }
}
