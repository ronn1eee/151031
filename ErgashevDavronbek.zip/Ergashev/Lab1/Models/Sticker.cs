﻿namespace Lab1.Models
{
    public class Sticker : BaseModel
    {
        public string Name { get; set; }
    }
}
