﻿namespace Lab1.Models
{
    public abstract class BaseModel
    {
        public long Id { get; set; }
    }
}
