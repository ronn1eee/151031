﻿using Lab1.Models;

namespace Lab1.Repositories.Interfaces
{
    public interface ICreatorRepository : IBaseRepository<Creator>
    {

    }
}
